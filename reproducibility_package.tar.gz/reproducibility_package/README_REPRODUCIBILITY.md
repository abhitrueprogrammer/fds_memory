# Reproducibility Package: Session-Persistent Repository Memory Architecture

**Manuscript**: Persistent Repository Memory for Autonomous Software Engineering Agents: Architectural Foundations, Empirical Retrieval, and Downstream Resolution Limits  
**Authors**: Abhinav Pant, Abhiram Anil, A Anjana Nair  
**Target Venue**: IEEE Conference on Software Engineering / Artificial Intelligence  

---

## 1. Package Directory Structure
```
reproducibility_package/
├── README_REPRODUCIBILITY.md          # Complete replication instructions
├── inventory.json                     # Metadata and base commits for SWE-bench Verified Mini (50 tasks)
├── swebench.yaml                      # SWE-bench configuration
├── .env.template                      # Environment variables template
├── memory_pilot/                      # Complete executable memory module source code
│   ├── interface.py                   # BaseMemory abstraction & data schemas
│   ├── condition_a.py                 # Stateless baseline
│   ├── condition_b.py                 # Snapshot lexical (TF-IDF)
│   ├── condition_c.py                 # Naive concatenation combo
│   └── condition_d.py                 # Structural AST symbol graph + Hybrid RRF + Staleness
├── scripts/                           # Reproducible experimental scripts
│   ├── run_statistical_tests.py       # 1-command statistical verification (Wilcoxon, McNemar, Wilson CIs)
│   ├── run_multi_repo_benchmark.py    # Cross-repository benchmark (Django + Sphinx, N=50)
│   ├── eval_component_ablations.py    # Architectural component-wise ablations & cache profiling
│   └── eval_drift_and_staleness.py    # 4 drift scenarios & lambda sensitivity analysis
├── results/                           # Raw machine-readable experimental output JSONs
│   ├── multi_repo_n50_benchmark.json
│   ├── comprehensive_retrieval_benchmark.json
│   ├── component_wise_ablations.json
│   ├── systematic_drift_and_staleness_study.json
│   ├── recurrent_cluster_summary.json
│   ├── eval_reports/                  # SWE-bench Docker harness evaluation reports
│   └── recurrent_cluster_experiment/  # Step-by-step trajectories and token usage logs
└── logs/
    └── run_evaluation/                # Raw execution traces, patches (patch.diff), test_output.txt
```

---

## 2. Fast 1-Command Statistical Verification
To instantly verify all manuscript statistics, confidence intervals, and Wilcoxon p-values without re-running long evaluations:
```bash
python scripts/run_statistical_tests.py
```

Expected output:
- Django (N=25): RRF MRR=0.5773 (+57.4% vs Lexical at 0.3667), R@1=44.0%, R@5=80.0%, Wilcoxon W=13.5, p=0.0077.
- Sphinx (N=25): RRF R@5=44.0% vs Lexical at 40.0% and Pure AST at 16.0%.
- Combined (N=50): RRF MRR=0.4110 (+22.7% vs Lexical at 0.3350), R@5=62.0% (31/50 hits).

---

## 3. Re-Running Empirical Benchmarks from Scratch

### Prerequisites
- Python 3.11+
- Virtual environment with dependencies:
```bash
pip install -r requirements.txt
# Dependencies: tree-sitter==0.26.0 tree-sitter-python==0.25.0 scikit-learn==1.9.1 scipy==1.17.1 datasets==5.1.0 unidiff==1.0.1
```

### Benchmarks
1. **Multi-Repository Benchmark (Django & Sphinx, N=50)**:
   ```bash
   python scripts/run_multi_repo_benchmark.py
   ```
2. **Component-Wise Ablations & Incremental Cache Profiling**:
   ```bash
   python scripts/eval_component_ablations.py
   ```
3. **Repository Drift Scenarios & Staleness Sensitivity Sweep**:
   ```bash
   python scripts/eval_drift_and_staleness.py
   ```
